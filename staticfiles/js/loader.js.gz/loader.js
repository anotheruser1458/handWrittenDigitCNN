loader = document.querySelector(".loader")

function toggleLoader() {
    if (loader.style.display == "none") loader.style.display = "block";
    else loader.style.display = "none"
}